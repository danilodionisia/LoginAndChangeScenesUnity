﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//gerenciador de cenas
using UnityEngine.SceneManagement;

public class BD : MonoBehaviour {


    public InputField login, password;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void TryLogin()
    {
        StartCoroutine(LoginAccount());
    }

    IEnumerator LoginAccount()
    {
        string resp, url = @"http://localhost/aula/";
        WWWForm Form = new WWWForm();
        Form.AddField("login", login.text);
        Form.AddField("password", password.text);

        WWW www = new WWW(url, Form);
        yield return www;

        resp = www.text;

        if (resp == "true")
        {
            print("Cena login certo");
            SceneManager.LoadScene("certo");
        }
        else
        {
            print("Cena erro de login");
            SceneManager.LoadScene("errado");
        }
        
    }
}
